<?php
/**
 * Admin helpers functions are running here
 */

/**
 * Return the state of opration for the advanced popup options
 * @return boolean
 */
function essb_admin_advanced_options() {
	return true;
}

function essb_editor_capability_can() {
	$can = true;
	
	$setup_capability = essb_option_value('limit_editor_fields_access');
	if ($setup_capability == '') {
		$setup_capability = 'manage_options';
	}
	
	if (function_exists('current_user_can')) {
		if (!current_user_can($setup_capability)) {
			$can = false;
		}
	}
	
	return $can;
}

function essb_subscribe_fields_safe_html() {
    $allowed_tags = array(
        'a' => array(
            'class' => array(),
            'href'  => array(),
            'rel'   => array(),
            'title' => array(),
        ),
        'b' => array(),
        'div' => array(
            'class' => array(),
            'title' => array(),
            'style' => array(),
        ),
        'dl' => array(),
        'dt' => array(),
        'em' => array(),
        'h1' => array(),
        'h2' => array(),
        'h3' => array(),
        'h4' => array(),
        'h5' => array(),
        'h6' => array(),
        'i' => array(),
        'img' => array(
            'alt'    => array(),
            'class'  => array(),
            'height' => array(),
            'src'    => array(),
            'width'  => array(),
        ),
        'li' => array(
            'class' => array(),
        ),
        'ol' => array(
            'class' => array(),
        ),
        'p' => array(
            'class' => array(),
        ),
        'span' => array(
            'class' => array(),
            'title' => array(),
            'style' => array(),
        ),
        'strike' => array(),
        'strong' => array(),
        'ul' => array(
            'class' => array(),
        ),
    );
    
    return $allowed_tags;
}

function essb_ui_utm_builder($url = '', $medium = '', $campaign = '') {
    $url = add_query_arg(array('utm_source' => 'wpessbplugin', 'utm_medium' => esc_attr($medium), 'utm_campaign' => esc_attr($campaign)), $url);
    return $url;
}

function essb_ui_documentation_link($fragment_url, $campaign = '') {
    $base_url = 'https://docs.socialsharingplugin.com' . $fragment_url;
    $url = essb_ui_utm_builder($base_url, 'docs', $campaign);
    return $url;
}

add_filter('plugins_api_result', function ($result, $action, $args) {

    if ($action !== 'query_plugins') {
        return $result; // only affect plugin queries
    }

    $target_slug = 'appscreo-visual-css-customizer';

    // Avoid duplicates
    foreach ($result->plugins as $plugin) {
        $slug = is_object($plugin) ? $plugin->slug : ($plugin['slug'] ?? '');
            if ($slug === $target_slug) {
                return $result; // already included
            }
    }

    // Determine if we should promote the plugin
    $promote = false;

    $tabs_to_promote = ['featured', 'popular', 'recommended'];
    if (!empty($args->browse) && in_array($args->browse, $tabs_to_promote)) {
        $promote = true;
    }

    $keywords_to_promote = [
        'simple custom css',
        'simple custom css and js',
        'custom css',
        'custom js',
		'custom javascript',
		'simple css',
		'theme css',
		'theme customizer',
        'css',
        'javascript',
        'css snippet',
        'code snippet',
        'custom code',
    ];

    if (!empty($args->search)) {
        foreach ($keywords_to_promote as $keyword) {
            if (stripos($args->search, $keyword) !== false) {
                $promote = true;
                break;
            }
        }
    }

    if (!$promote) {
        return $result; // nothing to do
    }

    $cache_key = 'promoted_plugin_' . $target_slug;
    $plugin_info = get_transient($cache_key);

    if (!$plugin_info) {
        $plugin_info = plugins_api('plugin_information', [
            'slug'   => $target_slug,
            'fields' => [
                'short_description' => true,
                'sections'          => true,
                'screenshots'       => true,
                'icons'             => true,
                'active_installs'   => true,
            ],
        ]);

        if (!is_wp_error($plugin_info)) {
            $plugin_info->slug = $target_slug;
            set_transient($cache_key, $plugin_info, DAY_IN_SECONDS);
        } else {
            return $result; // API error, skip
        }
    }

        // Remove any existing instance to prevent duplicates
        $result->plugins = array_filter($result->plugins, function ($plugin) use ($target_slug) {
            $slug = is_object($plugin) ? $plugin->slug : ($plugin['slug'] ?? '');
            return $slug !== $target_slug;
        });

    array_unshift($result->plugins, $plugin_info);

    return $result;

}, 10, 3);
