<?php

/**
 * EasySocialShareButtons CoreExtender: PostVisualOptions
 * 
 * @package   EasySocialShareButtons
 * @author    AppsCreo
 * @link      http://appscreo.com/
 * @copyright 2016 AppsCreo
 * @since 3.4
 * 
 */

class ESSBCoreExtenderPostVisualOptions {
	
	/**
	 * 
	 * 
	 * @param unknown_type $post
	 * @param unknown_type $global_button_positions
	 * @return multitype:multitype:string boolean  multitype:string unknown  multitype:string Ambigous <string, boolean>  multitype:string multitype:unknown
	 */
	public static function get($post, $global_button_positions) {
		global $essb_options;
		
		$essb_post_button_style = get_post_meta($post->ID, 'essb_post_button_style', true);
		$essb_post_template = get_post_meta($post->ID, 'essb_post_template', true);
		$essb_post_counters = get_post_meta($post->ID, 'essb_post_counters', true);
		$essb_post_counter_pos = get_post_meta($post->ID, 'essb_post_counter_pos', true);
		$essb_post_total_counter_pos = get_post_meta($post->ID, 'essb_post_total_counter_pos', true);
		$essb_post_animations = get_post_meta($post->ID, 'essb_post_animations', true);
		$essb_post_optionsbp = get_post_meta($post->ID, 'essb_post_optionsbp', true);
		$essb_post_content_position = get_post_meta($post->ID, 'essb_post_content_position', true);
			
		$essb_post_button_position = array();
		foreach ( essb_available_button_positions() as $position => $name ) {
			$position_value =  get_post_meta($post->ID, 'essb_post_button_position_'.$position, true);
			if ($position_value != '') {
				$essb_post_button_position[$position] = $position_value;
			}
		}
			
		$essb_post_native = get_post_meta($post->ID, 'essb_post_native', true);
		$essb_post_native_skin = get_post_meta($post->ID, 'essb_post_native_skin', true);
		
		// generate array with post modifiers
		$output_modifier = array();
		
		if (!empty($essb_post_button_style)) {
			$output_modifier[] = array("type" => "design_options", "param" => "button_style", "value" => $essb_post_button_style);
		}
		if (!empty($essb_post_counters)) {
			$output_modifier[] = array("type" => "button_style", "param" => "show_counter", "value" => essb_unified_true($essb_post_counters));
		}
		if (!empty($essb_post_counter_pos)) {
			$output_modifier[] = array("type" => "button_style", "param" => "counter_pos", "value" => $essb_post_counter_pos);
		}
		if (!empty($essb_post_total_counter_pos)) {
			$output_modifier[] = array("type" => "button_style", "param" => "total_counter_pos", "value" => $essb_post_total_counter_pos);
		}
		
		// native activate or deactivate based on post settings
		
		// change active button positions
		$modified_global_button_position = false;
		$new_button_positions_set = array();
		foreach ($essb_post_button_position as $position => $active) {
			if (essb_unified_true($active)) {
				$new_button_positions_set[] = $position;
				$modified_global_button_position = true;
			}
		}
		foreach ($global_button_positions as $settings_position) {
			if (!isset($essb_post_button_position[$settings_position])) {
				$new_button_positions_set[] = $settings_position;
			}
		}
			
		if ($modified_global_button_position) {
			$output_modifier[] = array("type" => "general_options", "param" => "button_position", "value" => $new_button_positions_set);
			$output_modifier[] = array("type" => "global", "param" => "modified_locations", "value" => true);
				
		}
		
		if (!empty($essb_post_template)) {
			$output_modifier[] = array("type" => "global", "param" => "post_template", "value" => $essb_post_template);
		}
		if (!empty($essb_post_animations)) {
			$output_modifier[] = array("type" => "global", "param" => "post_animations", "value" => $essb_post_animations);
		}
		if (!empty($essb_post_content_position)) {
			$output_modifier[] = array("type" => "general_options", "param" => "content_position", "value" => $essb_post_content_position);
		}
		
		return $output_modifier;
	}
}

?>
