<?php
/**
 * Encode custom symbols only of the URL
 * 
 * @param unknown_type $share
 * @return mixed
 */
function essb_buttonhelper_encode_url_sharing($share) {
	$share['short_url_twitter'] = urlencode($share['short_url_twitter']);
	$share['full_url'] = urlencode($share['full_url']);
	$share ['url'] = urlencode($share['url']);
	$share['full_url'] = str_replace('&', '&amp;', $share['full_url'] );
	$share['url'] = str_replace('&', '&amp;', $share['url'] );
	
	return $share;
}

function essb_buttonhelper_encode_text($share) {
	$share['twitter_tweet'] = str_replace("+", " ", $share['twitter_tweet']);
	$share ['title'] = urlencode($share['title']);
	$share ['twitter_tweet'] = urlencode($share['twitter_tweet']);
	$share ['description'] = urlencode($share['description']);
	$share['twitter_tweet'] = str_replace(" ", "%20", $share['twitter_tweet']);
	$share['twitter_tweet'] = str_replace("+", "%20", $share['twitter_tweet']);
	
	$share['twitter_tweet'] = str_replace('&', '&amp;', $share['twitter_tweet'] );
	$share['title'] = str_replace('&', '&amp;', $share['title'] );
	$share['description'] = str_replace('&', '&amp;', $share['description'] );
	
	return $share;
}

