<?php

/**
 * Plugin deactivation script
 *
 * @package EasySocialShareButtons
 * @author  appscreo
 * @since   10.8.2
 * @version 1.0.0
 */

function essb_on_plugin_deactivate()
{
    // 01. Clear cache directory 
    essb_cleanup_cache_on_deactivation();

    // 02. Clear Mail Sender Salt Key
    delete_option(ESSB3_MAIL_SALT);

    // 03. Clear Loggers for Share Counter and Followers Counter
    if (!class_exists('ESSB_Logger_ShareCounter_Update')) {
        include_once(ESSB3_CLASS_PATH . 'loggers/class-sharecounter-update.php');
    }

    ESSB_Logger_ShareCounter_Update::clear();

    if (!class_exists('ESSB_Logger_Followers_Update')) {
        include_once(ESSB3_CLASS_PATH . 'loggers/class-followers-update.php');
    }

    ESSB_Logger_Followers_Update::clear();
}

function essb_cleanup_cache_on_deactivation()
{
    $cache_dir = WP_CONTENT_DIR . '/cache/essb-cache';

    // Check if the directory exists
    if (file_exists($cache_dir)) {
        // Remove all files and subdirectories
        $files = glob($cache_dir . '/*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }

        // Remove the directory itself
        rmdir($cache_dir);
    }
}
