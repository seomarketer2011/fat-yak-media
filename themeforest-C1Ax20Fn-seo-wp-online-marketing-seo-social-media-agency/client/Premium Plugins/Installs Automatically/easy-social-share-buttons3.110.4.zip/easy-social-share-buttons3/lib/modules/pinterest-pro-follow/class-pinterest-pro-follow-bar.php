<?php
class ESSB_Pinterest_Pro_Follow_Bar
{

    public static $instance;

    public function __construct()
    {
        add_action('template_redirect', array($this, 'register_and_load'));
    }

    public static function get_instance()
    {
        if (! (self::$instance instanceof self)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function register_and_load()
    {
        if (essb_options_bool_value('pinpro_bar_content')) {
            if (ESSB_Plugin_Loader::post_type_allowed('pinpro_bar')) {
                add_filter('the_content', array($this, 'content_bar'));
            }
        }

        if (essb_options_bool_value('pinpro_bar_woocommerce')) {
            add_action('woocommerce_share', array($this, 'woocommerce_bar'));
        }

        if (essb_options_bool_value('pinpro_bar_floating')) {

            $can_add_floating = true;
            if (
                ESSB_Plugin_Loader::post_types_settings_exist('pinpro_bar_floating') &&
                !ESSB_Plugin_Loader::post_type_allowed('pinpro_bar_floating')
            ) {
                $can_add_floating = false;
            }

            if ($can_add_floating) {
                add_action('wp_footer', array($this, 'floating_bar'));
            }
        }
    }

    public function generate_follow_bar($location = '')
    {
        $output = '';

        $user = essb_options_value('pinpro_bar_user');
        $profile_url = essb_options_value('pinpro_bar_url');
        $bar_text = essb_options_value('pinpro_bar_text');
        $template = essb_options_value('pinpro_bar_template');

        $pinpro_bar_template_bg = essb_options_value('pinpro_bar_template_bg');
        $pinpro_bar_template_text = essb_options_value('pinpro_bar_template_text');
        $pinpro_bar_template_hover_bg = essb_options_value('pinpro_bar_template_hover_bg');
        $pinpro_bar_template_hover_text = essb_options_value('pinpro_bar_template_hover_text');

        if ($template == 'custom') {
            ESSB_Runtime_CSS_Builder::init('pinterest-bar-custom');

            if (!empty($pinpro_bar_template_bg)) {
                ESSB_Runtime_CSS_Builder::register('pinterest-bar-custom', '.pinterest-bar-custom', '--pinterest-bar-user-bg', $pinpro_bar_template_bg);
            }

            if (!empty($pinpro_bar_template_text)) {
                ESSB_Runtime_CSS_Builder::register('pinterest-bar-custom', '.pinterest-bar-custom', '--pinterest-bar-user-text', $pinpro_bar_template_text);
            }

            if (!empty($pinpro_bar_template_hover_bg)) {
                ESSB_Runtime_CSS_Builder::register('pinterest-bar-custom', '.pinterest-bar-custom', '--pinterest-bar-user-hover-bg', $pinpro_bar_template_hover_bg);
            }

            if (!empty($pinpro_bar_template_hover_text)) {
                ESSB_Runtime_CSS_Builder::register('pinterest-bar-custom', '.pinterest-bar-custom', '--pinterest-bar-user-hover-text', $pinpro_bar_template_hover_text);
            }


            $output .= ESSB_Dynamic_CSS_Builder::output_inline_code('pinterest-bar-custom', ESSB_Runtime_CSS_Builder::compile('pinterest-bar-custom'), true);
        }

        $salt = mt_rand();

        if (empty($bar_text)) {
            $bar_text = 'Follow @{username} on Pinterest';
        }

        $bar_text = str_replace('{username}', $user, $bar_text);

        $root_classes = array();
        $root_classes[] = 'pinterest-follow-bar';
        $root_classes[] = 'pinterest-follow-bar-' . $salt;

        if ($location == 'floating') {
            $mobile_display = essb_options_value('pinpro_bar_floating_mobile');
            if (empty($mobile_display)) {
                $mobile_display = 'button';
            }
            $root_classes[] = 'pinterest-bar-mobile-' . $mobile_display;
            $floating_template = essb_options_value('pinpro_bar_template_floating');
            if (!empty($floating_template)) {
                $template = $floating_template;
            }
        }

        $root_classes[] = 'pinterest-follow-bar-' . $location;
        $root_classes[] = 'pinterest-bar-' . $template;

        $output .= '<div class="' . esc_attr(join(' ', $root_classes)) . '">';
        $output .= '<a href="' . esc_url($profile_url) . '" target="_blank" rel="noopener">';
        $output .= '<svg class="pin-icon" viewBox="0 0 24 24" fill="currentColor">';
        $output .= '<path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.041-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.055-4.718-4.988-4.718-3.395 0-5.39 2.544-5.39 5.178 0 1.025.395 2.127.889 2.726.096.118.11.22.083.343-.086.378-.279 1.199-.316 1.367-.046.217-.156.264-.36.159-1.333-.689-2.166-2.847-2.166-4.585 0-3.735 2.714-7.168 7.822-7.168 4.108 0 7.303 2.923 7.303 6.827 0 4.073-2.568 7.351-6.123 7.351-1.194 0-2.319-.621-2.703-1.355 0 0-.59 2.249-0.734 2.801-.268.995-1.004 2.245-1.504 3.005 1.128.343 2.32.531 3.556.531 6.627 0 12-5.373 12-12 0-6.627-5.373-12-12-12z"/>';
        $output .= '</svg>';
        $output .= '<span>' . esc_html($bar_text) . '</span>';
        $output .= '</a>';
        $output .= '</div>';

        return $output;
    }

    public function output_follow_bar($location = '')
    {
        echo $this->generate_follow_bar($location);
    }

    public function woocommerce_bar()
    {
        $this->output_follow_bar('woocommerce');
    }

    public function floating_bar()
    {
        $this->output_follow_bar('floating');
    }

    public function content_bar($content)
    {

        $before = '';
        $after = '';

        $position = essb_option_value('pinpro_bar_content_position');

        if ($position == 'above' || $position == 'both') {
            $before = $this->generate_follow_bar('content-before');
        }

        if ($position == 'below' || $position == 'both') {
            $after = $this->generate_follow_bar('content-after');
        }

        return $before . $content . $after;
    }


    private function minify_advanced($css = '')
    {
        // Normalize whitespace
        $css = preg_replace('/\s+/', ' ', $css);

        // Remove spaces before and after comment
        $css = preg_replace('/(\s+)(\/\*(.*?)\*\/)(\s+)/', '$2', $css);

        // Remove comment blocks, everything between /* and */, unless
        // preserved with /*! ... */ or /** ... */
        $css = preg_replace('~/\*(?![\!|\*])(.*?)\*/~', '', $css);

        // Remove ; before }
        $css = preg_replace('/;(?=\s*})/', '', $css);

        // Remove space after , : ; { } */ >
        $css = preg_replace('/(,|:|;|\{|}|\*\/|>) /', '$1', $css);

        // Remove space before , ; { } ( ) >
        $css = preg_replace('/ (,|;|\{|}|\(|\)|>)/', '$1', $css);

        // Strips leading 0 on decimal values (converts 0.5px into .5px)
        $css = preg_replace('/(:| )0\.([0-9]+)(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}.${2}${3}', $css);

        // Strips units if value is 0 (converts 0px to 0)
        $css = preg_replace('/(:| )(\.?)0(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}0', $css);

        // Converts all zeros value into short-hand
        $css = preg_replace('/0 0 0 0/', '0', $css);

        // Shortern 6-character hex color codes to 3-character where possible
        $css = preg_replace('/#([a-f0-9])\\1([a-f0-9])\\2([a-f0-9])\\3/i', '#\1\2\3', $css);

        return trim($css);
    }
}


ESSB_Pinterest_Pro_Follow_Bar::get_instance();
