<?php

class ESSB_Share_Position extends ESSB_Share_Position_Base
{
    private $settings_page = 'where';

    function __construct($id = '', $name = '', $type = '', $options = []) {
        $this->set_id($id);
        $this->set_name($name);
        $this->set_type($type);

        if (class_exists('ESSBControlCenter')) {
            $this->attach_admin_page($this->settings_page);
        }

        if (isset($options['supports'])) {
            $this->set_supports($options['supports']);
        }

        if (isset($options['styles_supported'])) {
            $this->set_styles_supported($options['styles_supported']);
        }

        if (isset($options['fixed_networks'])) {
            $this->set_limited_network_list($options['fixed_networks']);
        }
    }
}
