<?php
if (!class_exists('ESSB_Cached_Share_Counters')) {
	include_once(ESSB3_PLUGIN_ROOT . 'lib/classes/share-button/class-cached-share-counters.php');
}

/**
 * Class ESSBCachedCounters
 *
 * @deprecated This class is maintained for compatibility purposes.
 * All functionality has been migrated to the new class ESSB_Cached_Share_Counters.
 * Please use ESSB_Cached_Share_Counters for future development.
 */
class ESSBCachedCounters
{

	public static function prepare_list_of_networks_with_counter($networks, $active_networks_list)
	{
		return ESSB_Cached_Share_Counters::prepare_list_of_networks_with_counter($networks, $active_networks_list);
	}

	public static function is_fresh_cache($post_id)
	{
		return ESSB_Cached_Share_Counters::is_fresh_cache($post_id);
	}

	public static function all_socaial_networks()
	{
		return ESSB_Cached_Share_Counters::all_socaial_networks();
	}

	
	public static function get_counters($post_id, $share = array(), $networks = array())
	{

		return ESSB_Cached_Share_Counters::get_counters($post_id, $share, $networks);
	}

	/**
	 * Recalculate the total share values
	 * 
	 * @param array $cached_counters
	 * @param array $networks
	 */
	public static function rebuild_totals($cached_counters = array(), $networks = array())
	{
		return ESSB_Cached_Share_Counters::rebuild_totals($cached_counters, $networks);
	}

	public static function update_counters($post_id, $url, $full_url, $networks = array(), $recover_mode = false)
	{
		return ESSB_Cached_Share_Counters::update_counters($post_id, $url, $full_url, $networks, $recover_mode);		
	}
}
