<?php
/**
 * Pre-loader
 * 
 * @package EasySocialShareButtons
 */

// Helper functionality
include_once (ESSB3_HELPERS_PATH . 'helpers-source-map.php');
include_once (ESSB3_HELPERS_PATH . 'helpers-utilities.php');
include_once (ESSB3_HELPERS_PATH . 'helpers-disabled-modules.php');
include_once (ESSB3_HELPERS_PATH . 'share-counters/helpers-sharecounters.php'); 
include_once (ESSB3_HELPERS_PATH . 'helpers-deprecated.php');
include_once (ESSB3_HELPERS_PATH . 'helpers-networks.php');


// Block Editor Integration
if (!essb_option_bool_value('gutenberg_disable_blocks')) {
    include_once (ESSB3_MODULES_PATH . 'block-editor/block-editor-loader.php');
}

// Post loading events (running before plugin real code
ESSB_Plugin_Options::load();

// Module assets manager
ESSB_Module_Assets::load();

