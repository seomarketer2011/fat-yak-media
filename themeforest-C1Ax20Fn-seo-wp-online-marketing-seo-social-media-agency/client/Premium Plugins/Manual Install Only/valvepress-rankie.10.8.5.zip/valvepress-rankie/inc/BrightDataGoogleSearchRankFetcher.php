<?php

final class BrightDataGoogleSearchRankFetcher
{
    private string $apiKey;

    public function __construct(string $apiKey)
    {
        $this->apiKey = $apiKey;
    }

    public function getRank(array $payload): array
    {
        $datasetId = 'gd_mfz5x93lmsjjjylob';
        $triggerUrl = "https://api.brightdata.com/datasets/v3/trigger?dataset_id={$datasetId}&include_errors=true";

        $triggerResponse = $this->sendRequest($triggerUrl, 'POST', [$payload]);

        if (empty($triggerResponse['snapshot_id'])) {
            throw new Exception('snapshot_id not found in trigger response: ' . json_encode($triggerResponse));
        }

        $snapshotId = $triggerResponse['snapshot_id'];

        do {
            sleep(5);

            $progressUrl = "https://api.brightdata.com/datasets/v3/progress/{$snapshotId}";
            $progress = $this->sendRequest($progressUrl);

            if (!empty($progress['status']) && $progress['status'] === 'failed') {
                throw new Exception('Bright Data snapshot failed: ' . json_encode($progress));
            }
        } while (empty($progress['status']) || $progress['status'] !== 'ready');

        $downloadUrl = "https://api.brightdata.com/datasets/v3/snapshot/{$snapshotId}?format=json";

        return $this->sendRequest($downloadUrl);
    }

    private function sendRequest(string $url, string $method = 'GET', ?array $body = null): array
    {
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->apiKey,
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 120,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);

            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
            }
        }

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception('cURL error: ' . $error);
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $decoded = json_decode($response, true);

        if ($httpCode < 200 || $httpCode >= 300) {
            throw new Exception("HTTP {$httpCode}: {$response}");
        }

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Invalid JSON response: ' . $response);
        }

        return $decoded;
    }
}
