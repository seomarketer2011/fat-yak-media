<?php

function essb_register_settings_metabox_optimize()
{
	global $post;

	$essb_post_share_message = "";
	$essb_post_share_url = "";
	$essb_post_share_image = "";
	$essb_post_share_text = "";
	$essb_post_fb_url = "";
	$essb_post_plusone_url = "";

	$essb_post_og_desc = "";
	$essb_post_og_title = "";
	$essb_post_og_image = "";
	$essb_post_og_video = "";
	$essb_post_og_video_w = "";
	$essb_post_og_video_h = "";

	$essb_post_og_image1 = "";
	$essb_post_og_image2 = "";
	$essb_post_og_image3 = "";
	$essb_post_og_image4 = "";

	$essb_post_twitter_desc = "";
	$essb_post_twitter_title = "";
	$essb_post_twitter_image = "";

	$essb_post_twitter_hashtags = "";
	$essb_post_twitter_username = "";
	$essb_post_twitter_tweet = "";
	$essb_activate_sharerecovery = "";

	$essb_post_pin_image = "";
	$essb_post_pin_desc = '';

	$post_address = "";

	if (!class_exists('ESSB_Cached_Share_Counters')) {
		include_once(ESSB3_PLUGIN_ROOT . 'lib/classes/share-button/class-cached-share-counters.php');
	}

	// the post is open into editor
	if (isset($_GET['action'])) {

		$custom = get_post_custom($post->ID);

		// custom post data sharing details
		$post_address = get_permalink($post->ID);

		$essb_post_share_message = isset($custom["essb_post_share_message"]) ? $custom["essb_post_share_message"][0] : "";
		$essb_post_share_url = isset($custom["essb_post_share_url"]) ? $custom["essb_post_share_url"][0] : "";
		$essb_post_share_image = isset($custom["essb_post_share_image"]) ? $custom["essb_post_share_image"][0] : "";
		$essb_post_share_text = isset($custom["essb_post_share_text"]) ? $custom["essb_post_share_text"][0] : "";
		$essb_post_fb_url = isset($custom["essb_post_fb_url"]) ? $custom["essb_post_fb_url"][0] : "";
		$essb_post_plusone_url = isset($custom["essb_post_plusone_url"]) ? $custom["essb_post_plusone_url"][0] : "";

		$essb_post_share_message = stripslashes($essb_post_share_message);
		$essb_post_share_text = stripslashes($essb_post_share_text);


		$essb_post_twitter_hashtags = isset($custom['essb_post_twitter_hashtags']) ? $custom['essb_post_twitter_hashtags'][0] : "";
		$essb_post_twitter_username = isset($custom['essb_post_twitter_username']) ? $custom['essb_post_twitter_username'][0] : "";
		$essb_post_twitter_tweet = isset($custom['essb_post_twitter_tweet']) ? $custom['essb_post_twitter_tweet'][0] : "";
		$essb_activate_ga_campaign_tracking = isset($custom['essb_activate_ga_campaign_tracking']) ? $custom['essb_activate_ga_campaign_tracking'][0] : "";

		$essb_post_pin_image = isset($custom["essb_post_pin_image"]) ? $custom["essb_post_pin_image"][0] : "";
		$essb_post_pin_desc = isset($custom["essb_post_pin_desc"]) ? $custom["essb_post_pin_desc"][0] : "";
		$essb_post_pin_id = isset($custom['essb_post_pin_id']) ? $custom['essb_post_pin_id'][0] : '';

		$essb_activate_sharerecovery = isset($custom['essb_activate_sharerecovery']) ? $custom['essb_activate_sharerecovery'][0] : '';

		// post share optimizations
		$essb_post_og_desc = isset($custom["essb_post_og_desc"]) ? $custom["essb_post_og_desc"][0] : "";
		$essb_post_og_title = isset($custom["essb_post_og_title"]) ? $custom["essb_post_og_title"][0] : "";
		$essb_post_og_image = isset($custom["essb_post_og_image"]) ? $custom["essb_post_og_image"][0] : "";
		$essb_post_og_image1 = isset($custom["essb_post_og_image1"]) ? $custom["essb_post_og_image1"][0] : "";
		$essb_post_og_image2 = isset($custom["essb_post_og_image2"]) ? $custom["essb_post_og_image2"][0] : "";
		$essb_post_og_image3 = isset($custom["essb_post_og_image3"]) ? $custom["essb_post_og_image3"][0] : "";
		$essb_post_og_image4 = isset($custom["essb_post_og_image4"]) ? $custom["essb_post_og_image4"][0] : "";
		$essb_post_og_url = isset($custom["essb_post_og_url"]) ? $custom["essb_post_og_url"][0] : "";


		$essb_post_og_desc = stripslashes($essb_post_og_desc);
		$essb_post_og_title = stripslashes($essb_post_og_title);
		$essb_post_og_video = isset($custom["essb_post_og_video"]) ? $custom["essb_post_og_video"][0] : "";
		$essb_post_og_video_w = isset($custom["essb_post_og_video_w"]) ? $custom["essb_post_og_video_w"][0] : "";
		$essb_post_og_video_h = isset($custom["essb_post_og_video_h"]) ? $custom["essb_post_og_video_h"][0] : "";

		$essb_post_twitter_desc = isset($custom["essb_post_twitter_desc"]) ? $custom["essb_post_twitter_desc"][0] : "";
		$essb_post_twitter_title = isset($custom["essb_post_twitter_title"]) ? $custom["essb_post_twitter_title"][0] : "";
		$essb_post_twitter_image = isset($custom["essb_post_twitter_image"]) ? $custom["essb_post_twitter_image"][0] : "";
		$essb_post_twitter_desc = stripslashes($essb_post_twitter_desc);
		$essb_post_twitter_title = stripslashes($essb_post_twitter_title);

		$essb_post_og_author = isset($custom['essb_post_og_author']) ? $custom['essb_post_og_author'][0] : '';
		$essb_post_og_author = stripslashes($essb_post_og_author);

		// Metabox draw start
		ESSBMetaboxInterface::draw_form_start('essb_social_share_optimize');

		$sidebar_options = array();

		if (essb_options_bool_value('opengraph_tags') || essb_options_bool_value('twitter_card')) {
			$sidebar_options[] = array(
				'field_id' => 'opengraph',
				'title' => esc_html__('Social Media Message', 'essb'),
				'icon' => 'share-alt',
				'type' => 'menu_item',
				'action' => 'default',
				'default_child' => ''
			);
		}

		$sidebar_options[] = array(
			'field_id' => 'twittertag',
			'title' => esc_html__('Custom X Message', 'essb') . (essb_options_bool_value('twitter_card') ? ' & Card Data' : ''),
			'icon' => 'twitter',
			'type' => 'menu_item',
			'action' => 'default',
			'default_child' => ''
		);


		$sidebar_options[] = array(
			'field_id' => 'pinterest',
			'title' => esc_html__('Pinterest Image', 'essb'),
			'icon' => 'pinterest-p',
			'type' => 'menu_item',
			'action' => 'default',
			'default_child' => ''
		);

		$sidebar_options[] = array(
			'field_id' => 'share',
			'title' => esc_html__('Share Parameters', 'essb'),
			'icon' => 'default',
			'type' => 'menu_item',
			'action' => 'default',
			'default_child' => ''
		);

		if (essb_option_bool_value('activate_utm')) {
			$sidebar_options[] = array(
				'field_id' => 'ga',
				'title' => esc_html__('GA Campaign Tracking Options', 'essb'),
				'icon' => 'pie-chart',
				'type' => 'menu_item',
				'action' => 'default',
				'default_child' => ''
			);
		}

		if (defined('ESSB3_SHARED_COUNTER_RECOVERY')) {
			$sidebar_options[] = array(
				'field_id' => 'sharerecover',
				'title' => esc_html__('Share Recovery', 'essb'),
				'icon' => 'refresh',
				'type' => 'menu_item',
				'action' => 'default',
				'default_child' => ''
			);
		}

		if (defined('ESSB3_CACHED_COUNTERS')) {
			if (!essb_options_bool_value('deactivate_share_counters')) {
				$sidebar_options[] = array(
					'field_id' => 'sharecounter',
					'title' => esc_html__('Social Shares', 'essb'),
					'icon' => 'sort-numeric-asc',
					'type' => 'menu_item',
					'action' => 'default',
					'default_child' => ''
				);
			}
		}

		if (essb_option_bool_value('activate_fake')) {
			$sidebar_options[] = array(
				'field_id' => 'fakecounter',
				'title' => esc_html__('Fake/Dummy Share Counter', 'essb'),
				'icon' => 'magic',
				'type' => 'menu_item',
				'action' => 'default',
				'default_child' => ''
			);
		} else if (!essb_option_bool_value('deactivate_postcount')) {
			$sidebar_options[] = array(
				'field_id' => 'internal',
				'title' => esc_html__('Internal Counter', 'essb'),
				'icon' => 'list-ol',
				'type' => 'menu_item',
				'action' => 'default',
				'default_child' => ''
			);
		}

		$show_short_urls = false;
		if (!essb_option_bool_value('deactivate_module_shorturl') && essb_option_bool_value('shorturl_activate') && class_exists('ESSB_Short_URL')) {
			$sidebar_options[] = array(
				'field_id' => 'shorturl',
				'title' => esc_html__('Short URLs', 'essb'),
				'icon' => 'scissors',
				'type' => 'menu_item',
				'action' => 'default',
				'default_child' => ''
			);

			$show_short_urls = true;
		}



		if (has_filter('essb_customize_metabox_extra_sections')) {
			$sidebar_options = apply_filters('essb_customize_metabox_extra_sections', $sidebar_options);
		}

		ESSBMetaboxInterface::draw_first_menu_activate('sso');

		ESSBMetaboxInterface::draw_sidebar($sidebar_options, 'sso');
		ESSBMetaboxInterface::draw_content_start('300', 'sso');

		if (essb_options_bool_value('opengraph_tags') || essb_options_bool_value('twitter_card')) {
			ESSBMetaboxInterface::draw_content_section_start('opengraph');

			if (essb_options_bool_value('opengraph_tags')) {

				essb_depend_load_function('essb_sso_metabox_interface_facebook', 'lib/admin/metabox/sso-tags.php');
				essb_sso_metabox_interface_facebook($post->ID);
			}

			ESSBMetaboxInterface::draw_content_section_end();
		}

		ESSBMetaboxInterface::draw_content_section_start('twittertag');
		ESSBOptionsFramework::reset_row_status();

		ESSBOptionsFramework::draw_options_row_start_full('inner-row-small');
		ESSBOptionsFramework::draw_help('', '', '', array('buttons' => array(
			'How to Customize The Shared Information On X (Custom Tweet)' => 'https://docs.socialsharingplugin.com/knowledgebase/how-to-customize-the-shared-information-on-twitter-custom-tweet/',

		)));
		ESSBOptionsFramework::draw_options_row_end();


		ESSBOptionsFramework::draw_holder_start(array('class' => 'essb-tweet-preview', 'user_id' => 'essb-tweet-preview'));
		ESSBOptionsFramework::draw_holder_end();

		ESSBOptionsFramework::draw_options_row_start(esc_html__('X Message', 'essb'), esc_html__('The default X sharing message will be automatically generating using the post/page title. Using this field you can customize it.', 'essb'));
		ESSBOptionsFramework::draw_textarea_field('essb_post_twitter_tweet', 'essb_metabox', $essb_post_twitter_tweet, $post->post_title);
		ESSBOptionsFramework::draw_options_row_end();

		ESSBOptionsFramework::draw_options_row_start(esc_html__('Set a personalized list of hashtags for this post/page', 'essb'), esc_html__('Enter delimited with a comma. Example: demotag1,demotag2,demotag3', 'essb'));
		ESSBOptionsFramework::draw_input_field('essb_post_twitter_hashtags', true, 'essb_metabox', $essb_post_twitter_hashtags, '', '', '', essb_option_value('twitterhashtags'));
		ESSBOptionsFramework::draw_options_row_end();

		ESSBOptionsFramework::draw_options_row_start(esc_html__('Overwrite default X username to be mentioned in the message', 'essb'), '');
		ESSBOptionsFramework::draw_input_field('essb_post_twitter_username', true, 'essb_metabox', $essb_post_twitter_username, '', '', '', essb_option_value('twitteruser'));
		ESSBOptionsFramework::draw_options_row_end();

		$short_url = wp_get_shortlink($post->ID);
		echo '<input type="hidden" id="essb_twitter_shorturl" value="' . esc_url($short_url) . '"/>';

		if (essb_options_bool_value('twitter_card')) {
			essb_depend_load_function('essb_sso_metabox_interface_facebook', 'lib/admin/metabox/sso-tags.php');
			essb_sso_metabox_interface_twitter($post->ID);
		}

		ESSBMetaboxInterface::draw_content_section_end();

		$pin_mode_title = '';
		$pin_mode_desc = '';
		ESSBMetaboxInterface::draw_content_section_start('pinterest');
		if (essb_is_pinterest_sniff_disabled()) {
			$pin_mode_title = esc_html__('Your Pinterest mode: Pin selected image only (or featured image if there is no selected image)', 'essb');
			$pin_mode_desc = esc_html__('In this mode, the Pinterest button will Pin only the selected image. When there is no custom-selected image the button will use the featured image.    You can change the button mode from Sharing -> Global Network Options -> Pinterest.', 'essb');
		} else {
			$pin_mode_title = esc_html__('Your Pinterest mode: Pin any image from the content', 'essb');
			$pin_mode_desc = esc_html__('In this mode when you press the Pinterest share dialog a new window will appear to select an image for Pin from those available in the content. There is another mode where you can specify a customized image only. You can change the button mode from Sharing -> Global Network Options -> Pinterest.', 'essb');
		}

		ESSBOptionsFramework::draw_options_row_start_full('inner-row-small');
		ESSBOptionsFramework::draw_hint($pin_mode_title, $pin_mode_desc, '', 'glowhelp');
		ESSBOptionsFramework::draw_options_row_end();

		ESSBOptionsFramework::draw_options_row_start(esc_html__('Pinterest Description', 'essb'), esc_html__('Add custom Pinterest description. It will be sent to your pin create command and it will also take part in the Pinterest-specific attribute data-pin-description.', 'essb'));
		ESSBOptionsFramework::draw_textarea_field('essb_post_pin_desc', 'essb_metabox', $essb_post_pin_desc);
		ESSBOptionsFramework::draw_options_row_end();

		if (essb_is_pinterest_sniff_disabled()) {
			ESSBOptionsFramework::reset_row_status();

			if (essb_option_bool_value('sso_external_images')) {
				echo '<div class="media-visible">';
			}
			ESSBOptionsFramework::draw_options_row_start(esc_html__('Change default Pinterest image', 'essb'), esc_html__('Choose personalized image that will be used to when you press Pinterest share button. We recommend using an image that is formatted in a 2:3 aspect ratio like 735 x 1102.', 'essb'));
			ESSBOptionsFramework::draw_fileselect_image_field('essb_post_pin_image', 'essb_metabox', $essb_post_pin_image);
			ESSBOptionsFramework::draw_options_row_end();

			if (essb_option_bool_value('sso_external_images')) {
				echo '</div>';
			}

			ESSBOptionsFramework::draw_options_row_start(esc_html__('Pin ID', 'essb'), esc_html__('Get more repins on your own Pins. The filled Pin ID will appear automatically on all images as data-pin-id attribute.', 'essb'));
			ESSBOptionsFramework::draw_input_field('essb_post_pin_id', true, 'essb_metabox', $essb_post_pin_id);
			ESSBOptionsFramework::draw_options_row_end();
		} else if (essb_option_bool_value('pinterest_alwayscustom') || essb_option_bool_value('pinterest_images') || essb_option_bool_value('pinterest_set_datamedia')) {

			if (essb_option_bool_value('pinterest_set_datamedia')) {
				if (essb_option_bool_value('sso_external_images')) {
					echo '<div class="media-visible">';
				}
				ESSBOptionsFramework::draw_options_row_start(esc_html__('Change default Pinterest image', 'essb'), esc_html__('Choose personalized image that will be used to when you press Pinterest share button. We recommend using an image that is formatted in a 2:3 aspect ratio like 735 x 1102.', 'essb'));
				ESSBOptionsFramework::draw_fileselect_image_field('essb_post_pin_image', 'essb_metabox', $essb_post_pin_image);
				ESSBOptionsFramework::draw_options_row_end();

				if (essb_option_bool_value('sso_external_images')) {
					echo '</div>';
				}
			}

			if (essb_option_bool_value('pinterest_alwayscustom') || essb_option_bool_value('pinterest_images')) {
				ESSBOptionsFramework::draw_options_row_start(esc_html__('Pin ID', 'essb'), esc_html__('Get more repins on your own Pins. The filled Pin ID will appear automatically on all images as data-pin-id attribute.', 'essb'));
				ESSBOptionsFramework::draw_input_field('essb_post_pin_id', true, 'essb_metabox', $essb_post_pin_id);
				ESSBOptionsFramework::draw_options_row_end();
			}
		}

		/**
		 * @since 10.1 Pinterest hidden images
		 */

		if (function_exists('wp_enqueue_media')) {
			wp_enqueue_media();
		} else {
			wp_enqueue_style('thickbox');
			wp_enqueue_script('media-upload');
			wp_enqueue_script('thickbox');
		}

		ESSBOptionsFramework::draw_options_row_start(esc_html__('Pinterest Hidden Images', 'essb'), '');
		echo '<a class="button button-secondary" data-post-id="' . esc_attr($post->ID) . '" href="#" id="essb-pinterest-hidden-image-picker">Add Image</a>';
		echo '<div id="essb-pinterest-hidden-image-list">';

		if (!class_exists('ESSB_Post_Meta')) {
			include_once(ESSB3_PLUGIN_ROOT . 'lib/classes/class-post-meta.php');
		}

		$essb_pinterest_hidden = essb_get_post_meta($post->ID, 'pinterest_hidden');

		if (!empty($essb_pinterest_hidden)) {
			$essb_pinterest_hidden = unserialize($essb_pinterest_hidden);

			foreach ($essb_pinterest_hidden as $image) {
				echo '<div class="essb-single-pinterest-hidden-image">';
				echo '<img src="' . $image . '" data-url="' . $image . '" />';
				echo '<span class="essb-single-pinterest-hidden-image-remove"><span class="dashicons dashicons-no-alt"></span></span>';
				echo '<input type="hidden" name="essb_pinterest_hidden[]" value="' . $image . '"/>';
				echo '</div>';
			}
		}

		echo '</div>';

		ESSBOptionsFramework::draw_options_row_end();

		ESSBMetaboxInterface::draw_content_section_end();

		ESSBMetaboxInterface::draw_content_section_start('share');

		ESSBOptionsFramework::reset_row_status();

		ESSBOptionsFramework::draw_hint('', esc_html__('Sharing over social networks use a specific set of parameters. Each network may use one or all of them. Those parameters plugin always fills on autopilot with the default details from the post. Using the provided fields below you can change the values send via the share command. The import you need to know is that most of the social networks use the URL as the only parameter. All share details appear from the connection to this URL social share optimization tags.', 'essb'), '', 'glowhelp');

		ESSBOptionsFramework::draw_options_row_start(esc_html__('URL', 'essb'), esc_html__('Provide custom URL to be shared.', 'essb'));
		ESSBOptionsFramework::draw_input_field('essb_post_share_url', true, 'essb_metabox', $essb_post_share_url);
		ESSBOptionsFramework::draw_options_row_end();

		ESSBOptionsFramework::draw_options_row_start(esc_html__('Message', 'essb'), esc_html__('Provide custom message to be shared (not all social networks support that option)', 'essb'));
		ESSBOptionsFramework::draw_input_field('essb_post_share_message', true, 'essb_metabox', $essb_post_share_message);
		ESSBOptionsFramework::draw_options_row_end();

		ESSBOptionsFramework::draw_options_row_start(esc_html__('Image', 'essb'), esc_html__('Custom image is support by Facebook when advanced sharing is enabled and Pinterest when sniff for images is disabled', 'essb'));
		ESSBOptionsFramework::draw_fileselect_field('essb_post_share_image', 'essb_metabox', $essb_post_share_image);
		ESSBOptionsFramework::draw_options_row_end();

		ESSBOptionsFramework::draw_options_row_start(esc_html__('Description', 'essb'), esc_html__('Custom description is support by Facebook when advanced sharing is enabled and Pinterest when sniff for images is disabled', 'essb'));
		ESSBOptionsFramework::draw_textarea_field('essb_post_share_text', 'essb_metabox', $essb_post_share_text);
		ESSBOptionsFramework::draw_options_row_end();
		ESSBMetaboxInterface::draw_content_section_end();


		if (essb_option_bool_value('activate_utm')) {
			ESSBMetaboxInterface::draw_content_section_start('ga');

			ESSBOptionsFramework::reset_row_status();
			ESSBOptionsFramework::draw_heading(esc_html__('Customize Google Analytics Campaign Tracking Options', 'essb'), '5');

			ESSBOptionsFramework::draw_options_row_start(esc_html__('Add Custom Google Analytics Campaign parameters to your URLs', 'essb'), esc_html__('Paste your custom campaign parameters in this field and they will be automatically added to shared addresses on social networks. Please note as social networks count shares via URL as unique key this option is not compatible with active social share counters as it will make the start from zero.', 'essb'));
			ESSBOptionsFramework::draw_input_field('essb_activate_ga_campaign_tracking', true, 'essb_metabox', $essb_activate_ga_campaign_tracking);
			ESSBOptionsFramework::draw_options_row_end();

			ESSBOptionsFramework::draw_options_row_start('', '', '', '2', false);
			print "<span style='font-weight: 400;'>You can visit <a href='https://support.google.com/analytics/answer/1033867?hl=en' target='_blank'>this page</a> for more information on how to use and generate these parameters.
			To include the social network into parameters use the following code <b>{network}</b>. When that code is reached it will be replaced with the network name (example: facebook). An example campaign trakcing code include network will look like this utm_source=essb_settings&utm_medium=needhelp&utm_campaign={network} - in this configuration when you press Facebook button {network} will be replaced with facebook, if you press Twitter button it will be replaced with twitter.</span>";
			ESSBOptionsFramework::draw_options_row_end();

			ESSBMetaboxInterface::draw_content_section_end();
		}

		if (defined('ESSB3_SHARED_COUNTER_RECOVERY')) {
			ESSBMetaboxInterface::draw_content_section_start('sharerecover');

			ESSBOptionsFramework::reset_row_status();
			ESSBOptionsFramework::draw_heading(esc_html__('Share Counter Recovery', 'essb'), '5');

			ESSBOptionsFramework::draw_options_row_start(esc_html__('Previous post url address', 'essb'), esc_html__('Provide custom previous url address of post if the automatic share counter recovery is not possible to guess the previous post address.', 'essb'));
			ESSBOptionsFramework::draw_input_field('essb_activate_sharerecovery', true, 'essb_metabox', $essb_activate_sharerecovery);
			ESSBOptionsFramework::draw_options_row_end();

			ESSBMetaboxInterface::draw_content_section_end();
		}

		if (defined('ESSB3_CACHED_COUNTERS')) {
			ESSBMetaboxInterface::draw_content_section_start('sharecounter');

			ESSBOptionsFramework::reset_row_status();

			$counter_cache_expire = ESSB_Cached_Share_Counters::get_post_meta($post->ID, 'essb_cache_expire');
			$counter_description = '';

			if (!empty($counter_cache_expire)) {
				$now = time();

				if ($now > $counter_cache_expire) {
					$counter_description = 'Counters will update on the next post load in the front-end.';
				} else {
					$counter_description = 'Next counter update will be at ' . date(DATE_RFC822, $counter_cache_expire) . '. Click the button below to update immediately, or use the plugin’s top menu while viewing the post as an administrator.';
				}
			} else {
				$counter_description = 'Counter update information is not available.';
			}

			ESSBOptionsFramework::draw_hint('The information will update only if you’re using a design that displays share counters.', $counter_description, '', 'glowhelp');


			ESSBOptionsFramework::draw_options_row_start_full();

			echo '<div class="essb-post-clear-counters">';
			echo '<a class="button button-primary" href="' . esc_url(add_query_arg('essb_counter_update', 'true', $post_address)) . '" target="_blank">Update Counters Now</a>&nbsp;';
			echo '<a class="button button-secondary" data-post-id="' . esc_attr($post->ID) . '" href="#" id="essb-delete-post-counter">Delete Counter Information</a>';
			echo "<span class='dashicons dashicons-yes'></span>";
			echo "<span class='spinner'></span>";
			echo '</div>';

			ESSBOptionsFramework::draw_options_row_end();


			$stored_counters = ESSB_Cached_Share_Counters::read_all_post_counters($post->ID);
			$listOfNetworks = essb_available_social_networks();

			echo '<div class="essb-sharecounter-status-block">';

			foreach ($listOfNetworks as $key => $data) {
				if ($key == 'facebook_like') {
					continue;
				}
				$value = isset($stored_counters[$key]) ? $stored_counters[$key] : 0;

				if ($key == 'twitter') {
					$key = 'twitter_x';
				}

				if (intval($value) != 0) {
					echo essb_meta_share_counter_block($key, $data['name'], $value);
				}
			}

			echo '</div>';


			ESSBMetaboxInterface::draw_content_section_end();
		}

		if (essb_option_bool_value('activate_fake')) {
			ESSBMetaboxInterface::draw_content_section_start('fakecounter');

			ESSBOptionsFramework::reset_row_status();
			ESSBOptionsFramework::draw_heading(esc_html__('Manage Fake/Dummy Share Counters', 'essb'), '5');
			ESSBOptionsFramework::draw_hint('', esc_html__('Using fields below you can manage your internal (fake, dummy) counters - change or set new values. If you choose a list of networks below you will see just them. Otherwise all networks will appear.', 'essb'));

			$listOfNetworks = essb_available_social_networks();

			$fake_networks = essb_option_value('fake_networks');
			if (!is_array($fake_networks)) {
				$fake_networks = array();
			}

			$minimal_fake = get_option('essb-fake');
			if (!is_array($minimal_fake)) {
				$minimal_fake = array();
			}
			if (!class_exists('ESSB_Cached_Share_Counters')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/classes/share-button/class-cached-share-counters.php');
			}
			foreach ($listOfNetworks as $key => $data) {

				if (count($fake_networks) > 0 && !in_array($key, $fake_networks)) {
					continue;
				}

				$minimal_fake_shares = isset($minimal_fake['fake_' . $key]) ? $minimal_fake['fake_' . $key] : '0';

				$value = ESSB_Cached_Share_Counters::get_post_meta($post->ID, 'essb_pc_' . $key);

				$desc = '';
				if (intval($value) < intval($minimal_fake_shares)) {
					$desc = 'The current value is lower than the global minial shares: ' . $minimal_fake_shares . '. In this case the minimal value will appear in front till post value become greater';
				}

				ESSBOptionsFramework::draw_options_row_start($data["name"], $desc);
				ESSBOptionsFramework::draw_input_field("essb_pc_" . $key, true, 'essb_metabox', $value);
				ESSBOptionsFramework::draw_options_row_end();
			}


			ESSBMetaboxInterface::draw_content_section_end();
		} else if (!essb_option_bool_value('deactivate_postcount')) {
			ESSBMetaboxInterface::draw_content_section_start('internal');

			$list = essb_admin_get_internal_counter_networks();

			ESSBOptionsFramework::reset_row_status();

			ESSBOptionsFramework::draw_options_row_start_full('');
			echo '<div class="essb-options-hint essb-options-hint-glowhelp">';
			echo '<div class="essb-options-hint-desc">';
			echo 'The internal counter goes up each time someone clicks the share button. This number is shown for networks that don’t have their own counter, or when you’ve chosen to use the internal counter for all networks.';
			echo '<br/>Below, you can adjust the internal counter values for the networks that support it. Which networks use an internal counter depends on the options you selected in the <b>Share Counter Settings</b> menu.';
			echo '</div>';
			echo '</div>';
			ESSBOptionsFramework::draw_options_row_end();

			ESSBOptionsFramework::draw_options_row_start_full('');
			echo '<div class="essb-options-hint essb-options-hint-danger">';
			echo '<div class="essb-options-hint-desc">';
			echo 'Use the fields below to adjust the internal counters for supported networks. After making changes, be sure to clear the post counter cache so the updated values are displayed correctly.';
			echo '</div>';
			echo '</div>';
			ESSBOptionsFramework::draw_options_row_end();


			$listOfNetworks = essb_available_social_networks();

			if (!class_exists('ESSB_Cached_Share_Counters')) {
				include_once(ESSB3_PLUGIN_ROOT . 'lib/classes/share-button/class-cached-share-counters.php');
			}

			foreach ($list as $key => $name) {

				$value = ESSB_Cached_Share_Counters::get_post_meta($post->ID, 'essb_pc_' . $key);

				$desc = '';

				if ($key == 'love') {
					$value = isset($custom['_essb_love']) ? $custom['_essb_love'][0] : "";
				}

				ESSBOptionsFramework::draw_options_row_start($name, $desc);
				ESSBOptionsFramework::draw_input_field("essb_pc_" . $key, true, 'essb_metabox', $value);
				ESSBOptionsFramework::draw_options_row_end();
			}


			ESSBMetaboxInterface::draw_content_section_end();
		}

		/**
		 * @since 8.0 Display all post short URLs and a clear button
		 */
		if ($show_short_urls) {
			ESSBMetaboxInterface::draw_content_section_start('shorturl');
			$short_url_cache_id = ESSB_Short_URL::post_base_short_cache_id();
			$global_short_url = essb_get_post_meta($post->ID, $short_url_cache_id);

			$other_short_urls = essb_get_post_meta_matching_keys($post->ID, $short_url_cache_id . '_');

			$url_count = 0;

			echo '<div class="essb-post-shorturl-list">';

			if (!empty($global_short_url)) {
				ESSBOptionsFramework::draw_options_row_start('Global short URL', '');
				echo esc_url($global_short_url);
				ESSBOptionsFramework::draw_options_row_end();
				$url_count++;
			}

			foreach ($other_short_urls as $key => $value) {
				ESSBOptionsFramework::draw_options_row_start(str_replace($short_url_cache_id . '_', '', $key), '');
				echo esc_url($value);
				ESSBOptionsFramework::draw_options_row_end();
				$url_count++;
			}

			echo '</div>';

			if ($url_count > 0) {
				echo '<div class="essb-post-clear-shorturl">';
				echo '<a class="button button-secondary" id="essb-clear-post-shorturl" data-post-id="' . esc_attr($post->ID) . '">Clear short URLs</a>';
				echo "<span class='dashicons dashicons-yes'></span>";
				echo "<span class='spinner'></span>";
				echo '</div>';
			} else {
				esc_html_e('This post does not have short URLs stored in the cache.', 'essb');
			}
			ESSBMetaboxInterface::draw_content_section_end();
		}

		wp_nonce_field('essb_admin_post_action', 'essb_admin_post_action_token');

		do_action('essb_customize_metabox_extra_options');

		ESSBMetaboxInterface::draw_content_end();
		ESSBMetaboxInterface::draw_form_end();
	}
}

function essb_register_settings_metabox_visual()
{
	global $post;

	if (isset($_GET['action'])) {

		$custom = get_post_custom($post->ID);
		$essb_post_button_style = isset($custom["essb_post_button_style"]) ? $custom["essb_post_button_style"][0] : "";
		$essb_post_template = isset($custom["essb_post_template"]) ? $custom["essb_post_template"][0] : "";
		$essb_post_counters = isset($custom["essb_post_counters"]) ? $custom["essb_post_counters"][0] : "";
		$essb_post_counter_pos = isset($custom["essb_post_counter_pos"]) ? $custom["essb_post_counter_pos"][0] : "";
		$essb_post_total_counter_pos = isset($custom["essb_post_total_counter_pos"]) ? $custom["essb_post_total_counter_pos"][0] : "";
		$essb_post_customizer = isset($custom["essb_post_customizer"]) ? $custom["essb_post_customizer"][0] : "";
		$essb_post_animations = isset($custom["essb_post_animations"]) ? $custom["essb_post_animations"][0] : "";
		$essb_post_optionsbp = isset($custom["essb_post_optionsbp"]) ? $custom["essb_post_optionsbp"][0] : "";
		$essb_post_content_position = isset($custom["essb_post_content_position"]) ? $custom["essb_post_content_position"][0] : "";

		// update for PHP 7.4
		$essb_post_button_position_ = array();

		foreach (essb_available_button_positions() as $position => $name) {
			$essb_post_button_position_[$position] = isset($custom["essb_post_button_position_" . $position]) ? $custom["essb_post_button_position_" . $position][0] : "";
		}

		$essb_post_native = isset($custom["essb_post_native"]) ? $custom["essb_post_native"][0] : "";
		$essb_post_native_skin = isset($custom["essb_post_native_skin"]) ? $custom["essb_post_native_skin"][0] : "";

		ESSBMetaboxInterface::draw_form_start('essb_social_share_visual');
		$sidebar_options = array();

		$sidebar_options[] = array(
			'field_id' => 'visual1',
			'title' => esc_html__('Button Style', 'essb'),
			'icon' => 'default',
			'type' => 'menu_item',
			'action' => 'default',
			'default_child' => ''
		);

		$sidebar_options[] = array(
			'field_id' => 'visual2',
			'title' => esc_html__('Button Display', 'essb'),
			'icon' => 'default',
			'type' => 'menu_item',
			'action' => 'default',
			'default_child' => ''
		);

		$sidebar_options[] = array(
			'field_id' => 'visual3',
			'title' => esc_html__('Native Buttons', 'essb'),
			'icon' => 'default',
			'type' => 'menu_item',
			'action' => 'default',
			'default_child' => ''
		);

		$converted_button_styles = essb_avaiable_button_style();
		$converted_button_styles[""] = "Default style from settings";

		$converted_counter_pos = essb_avaliable_counter_positions();
		$converted_counter_pos[""] = "Default value from settings";

		$converted_total_counter_pos = essb_avaiable_total_counter_position();
		$converted_total_counter_pos[""] = "Default value from settings";

		$converted_content_position = array();
		$converted_content_position[""] = "Default value from settings";
		$converted_content_position["no"] = "No display inside content (deactivate content positions)";
		foreach (essb_avaliable_content_positions() as $position => $data) {
			$converted_content_position[$position] = $data["label"];
		}

		$animations_container = array();
		$animations_container[""] = "Default value from settings";
		foreach (essb_available_animations() as $key => $text) {
			if ($key != '') {
				$animations_container[$key] = $text;
			} else {
				$animations_container['no'] = 'No amination';
			}
		}

		$yesno_object = array();
		$yesno_object[""] = "Default value from settings";
		$yesno_object["yes"] = "Yes";
		$yesno_object["no"] = "No";

		ESSBMetaboxInterface::draw_first_menu_activate('visual');
		ESSBMetaboxInterface::draw_sidebar($sidebar_options, 'visual');
		ESSBMetaboxInterface::draw_content_start('300', 'visual');

		ESSBMetaboxInterface::draw_content_section_start('visual1');
		ESSBMetaboxOptionsFramework::reset_row_status();
		ESSBMetaboxOptionsFramework::draw_heading(esc_html__('Button Style', 'essb'), '3');

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Button style', 'essb'), esc_html__('Change default button style.', 'essb'));
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_button_style', $converted_button_styles, false, 'essb_metabox', $essb_post_button_style);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Template', 'essb'), esc_html__('Change default template.', 'essb'));
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_template', essb_available_tempaltes4(true), false, 'essb_metabox', $essb_post_template);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Counters', 'essb'), '');
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_counters', $yesno_object, false, 'essb_metabox', $essb_post_counters);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Counter position', 'essb'), '');
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_counter_pos', $converted_counter_pos, false, 'essb_metabox', $essb_post_counter_pos);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Total counter position', 'essb'), '');
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_total_counter_pos', $converted_total_counter_pos, false, 'essb_metabox', $essb_post_total_counter_pos);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Activate style customizer', 'essb'), '');
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_customizer', $yesno_object, false, 'essb_metabox', $essb_post_customizer);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Activate animations', 'essb'), '');
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_animations', $animations_container, false, 'essb_metabox', $essb_post_animations);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Activate options by button position', 'essb'), '');
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_optionsbp', $yesno_object, false, 'essb_metabox', $essb_post_optionsbp);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxInterface::draw_content_section_end();

		ESSBMetaboxInterface::draw_content_section_start('visual2');
		ESSBMetaboxOptionsFramework::reset_row_status();
		ESSBMetaboxOptionsFramework::draw_heading(esc_html__('Button Position', 'essb'), '3');

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Content position', 'essb'), esc_html__('Change default content position', 'essb'));
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_content_position', $converted_content_position, false, 'essb_metabox', $essb_post_content_position);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		foreach (essb_available_button_positions() as $position => $name) {
			ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Activate ' . $name["label"], 'essb'), esc_html__('Activate additional display position', 'essb'));
			ESSBMetaboxOptionsFramework::draw_select_field('essb_post_button_position_' . $position, $yesno_object, false, 'essb_metabox', $essb_post_button_position_[$position]);
			ESSBMetaboxOptionsFramework::draw_options_row_end();
		}

		ESSBMetaboxInterface::draw_content_section_end();

		ESSBMetaboxInterface::draw_content_section_start('visual3');
		ESSBMetaboxOptionsFramework::reset_row_status();
		ESSBMetaboxOptionsFramework::draw_heading(esc_html__('Native Buttons', 'essb'), '3');

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Activate native buttons', 'essb'), '');
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_native', $yesno_object, false, 'essb_metabox', $essb_post_native);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxOptionsFramework::draw_options_row_start(esc_html__('Activate native buttons skin', 'essb'), '');
		ESSBMetaboxOptionsFramework::draw_select_field('essb_post_native_skin', $yesno_object, false, 'essb_metabox', $essb_post_native_skin);
		ESSBMetaboxOptionsFramework::draw_options_row_end();

		ESSBMetaboxInterface::draw_content_section_end();

		ESSBMetaboxInterface::draw_content_end();
		ESSBMetaboxInterface::draw_form_end();
	}
}

function essb_register_settings_metabox_onoff()
{
	global $post;

	if (isset($_GET['action'])) {

		$custom = get_post_custom($post->ID);
		$essb_off = isset($custom["essb_off"]) ?  $custom["essb_off"][0] : "false";

		ESSBMetaboxInterface::draw_form_start('essb_global_metabox');

		ESSBOptionsFramework::draw_section_start();

		ESSBOptionsFramework::draw_options_row_start_full('inner-row');
		ESSBOptionsFramework::draw_title(esc_html__('Turn off Easy Social Share Buttons', 'essb'), esc_html__('Turn off the functions of the plugin and assets loading on this post.', 'essb'), 'inner-row');
		ESSBOptionsFramework::draw_options_row_end();

		ESSBOptionsFramework::draw_options_row_start_full('inner-row-small');
		ESSBOptionsFramework::draw_switch_field('essb_off', 'essb_metabox', $essb_off, esc_html__('Yes', 'essb'), esc_html__('No', 'essb'));
		ESSBOptionsFramework::draw_options_row_end();

		ESSBOptionsFramework::draw_section_end();

		ESSBMetaboxInterface::draw_form_end();
	}
}



function essb_register_settings_metabox_stats()
{
	global $post, $essb_networks;

	if (isset($_GET['action'])) {

		$post_id = $post->ID;
		ESSBSocialShareAnalyticsBackEnd::init_addional_settings();

		$essb_date_to = "";
		$essb_date_from = "";

		if ($essb_date_to == '') {
			$essb_date_to = date("Y-m-d");
		}

		if ($essb_date_from == '') {
			$essb_date_from = date("Y-m-d", strtotime(date("Y-m-d", strtotime(date("Y-m-d"))) . "-1 month"));
		}


		include_once ESSB3_PLUGIN_ROOT . 'lib/modules/social-share-analytics/views/view-metabox-post.php';
	}
}

function essb_admin_get_internal_counter_networks()
{
	$basic_network_list = 'twitter,linkedin,facebook,pinterest,google,stumbleupon,vk,reddit,buffer,love,ok,xing,mail,print,comments,yummly';
	$avoid_network_list = 'more,share,subscribe,copy,mwp,comments';

	$basic_array = explode(',', $basic_network_list);
	$avoid_array = explode(',', $avoid_network_list);
	$networks_with_api = array('facebook', 'pinterest', 'vk', 'ok', 'reddit', 'buffer', 'xing', 'yummly');

	$internal_counters = essb_option_bool_value('active_internal_counters');
	$no_mail_print_counter = essb_option_bool_value('deactive_internal_counters_mail');

	$api_internal_mode = essb_option_bool_value('active_internal_counters_advanced');
	$api_networks = essb_option_value('active_internal_counters_advanced_networks');

	if (!is_array($api_networks)) {
		$api_networks = array();
	}

	$count_networks = array();

	$listOfNetworks = essb_available_social_networks();

	foreach ($listOfNetworks as $key => $data) {
		if (in_array($key, $avoid_array)) {
			continue;
		}

		if (!in_array($key, $basic_array) && !$internal_counters) {
			continue;
		}

		if (($key == 'print' || $key == 'mail') && $no_mail_print_counter) {
			continue;
		}

		if (in_array($key, $networks_with_api)) {
			if (!$api_internal_mode) {
				continue;
			} else {
				if (!in_array($key, $api_networks)) {
					continue;
				}
			}
		}

		$count_networks[$key] = $data['name'];
	}

	return $count_networks;
}

function essb_meta_share_counter_block($network_id, $network_name, $value)
{
	$r = '';

	$r .= '<div class="essb-sharecounter-status essb-sharecounter-status-' . esc_attr($network_id) . '" style="background-color: ' . ESSB_Share_Button_Styles::get_single_network_color($network_id).';">';
	$r .= '<span class="essb-svg-icon">' . essb_svg_replace_font_icon($network_id) . '</span>';
	$r .= '<span class="essb-network-name">' . $network_name . '</span>';
	$r .= '<span class="essb-share-counter">' . $value . '</span>';
	$r .= '</div>';

	return $r;
}
