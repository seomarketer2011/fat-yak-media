<?php
/**
 * EasySocialShareButtons DisplayMethod: Mobile
 *
 * @package   EasySocialShareButtons
 * @author    AppsCreo
 * @link      http://appscreo.com/
 * @copyright 2016 AppsCreo
 * @since 3.6
 *
 */

class ESSBDisplayMethodMobile {
	public static function generate_sharepoint_code($options, $share_buttons, $is_shortcode, $shortcode_options = array()) {
		$output = '';
		
		$icon = essb_option_value('mobile_sharepoint_icon');
		if ($icon == '') { $icon = 'share'; }
		
		$position = essb_option_value('mobile_sharepoint_position');
		$adjust_x = essb_option_value('mobile_sharepoint_position_x');
		$adjust_y = essb_option_value('mobile_sharepoint_position_y');
		
		if (empty($adjust_x)) {
			$adjust_x = '0';
		}

		if (empty($adjust_y)) {
			$adjust_y = '0';
		}
		
		$css_adjust = '';
		if ($position == '') {
			$css_adjust = 'left:'.$adjust_x.'px;bottom:'.$adjust_y.'px;';
		}
		else {
			$css_adjust = 'right:'.$adjust_x.'px;bottom:'.$adjust_y.'px;left:auto;';
		}
		
		$output .= '<div class="essb-mobile-sharepoint" onclick="essb.mobile_sharebar_open();" style="'.$css_adjust.'">';
		$output .= '<div class="essb-mobile-sharepoint-icon">'.essb_svg_replace_font_icon($icon).'</div>';
		$output .= '</div>';
		
		$output .= '<div class="essb-mobile-sharebar-window">';
		$output .= '<div class="essb-mobile-sharebar-window-close-title" onclick="essb.mobile_sharebar_close(); return false;">';
		$output .= '<a href="#" class="essb-mobile-sharebar-window-close">'.essb_svg_replace_font_icon('close').'</a>';
		$output .= '</div>';
		$output .= '<div class="essb-mobile-sharebar-window-content">';
		$output .= $share_buttons;
		$output .= '</div>';
		$output .= '</div>';
		$output .= '<div class="essb-mobile-sharebar-window-shadow"></div>';		
		
		return $output;
	}
	
	public static function generate_sharebar_code($options, $share_buttons, $is_shortcode, $shortcode_options = array()) {
		$output = '';
	
		$mobile_sharebar_text = essb_object_value($options, 'mobile_sharebar_text');
		if ($mobile_sharebar_text == "") {
			$mobile_sharebar_text = esc_html__("Share this", 'essb');
		}
			
		$output = "";
		
		$icon = essb_option_value('mobile_sharebar_icon');
		if ($icon == '') { $icon = 'share'; }
			
		$output .= '<div class="essb-mobile-sharebar" onclick="essb.mobile_sharebar_open();">';
		$output .= '<div class="essb-mobile-sharebar-inner">';
		$output .= sprintf ('<div class="essb-mobile-sharebar-icon">'.essb_svg_replace_font_icon($icon).'</div><div class="essb-mobile-sharebar-text">%1$s</div>', $mobile_sharebar_text);
		$output .= '</div>';
		$output .= '</div>';
			
		$output .= '<div class="essb-mobile-sharebar-window">';
		$output .= '<div class="essb-mobile-sharebar-window-close-title" onclick="essb.mobile_sharebar_close(); return false;">';
		$output .= '<a href="#" class="essb-mobile-sharebar-window-close" >'.essb_svg_replace_font_icon('close').'</a>';
		$output .= '</div>';
		$output .= '<div class="essb-mobile-sharebar-window-content">';
		
		$output .= $share_buttons;
		
		$output .= '</div>';
		$output .= '</div>';
		$output .= '<div class="essb-mobile-sharebar-window-shadow"></div>';
		
		return $output;
	}
}