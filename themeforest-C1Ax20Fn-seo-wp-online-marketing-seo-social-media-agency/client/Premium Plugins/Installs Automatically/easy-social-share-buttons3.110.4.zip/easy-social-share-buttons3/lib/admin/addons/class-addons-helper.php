<?php

/**
 * ESSB Add-ons Handler
 * 
 * Handles retrieval and caching of add-ons from the ESSB API
 * 
 * @package EasySocialShareButtons
 * @since 11.0
 */

class ESSB_Addons_Helper {

    public static function get_tmga_addons() {
        $api_list = ESSB_MyAddons_API::get_free_addons_basic();
        $plugins = array();

        foreach ($api_list as $addon) {
            $source = $addon['source'];
            $source = str_replace('{activationKey}', ESSBActivationManager::getActivationCode(), $source);
            $source = str_replace('{domain}', esc_url(ESSBActivationManager::getSiteURL()), $source);

            $addon['source'] = $source;
            $plugins[] = $addon;
        }

        return $plugins;
    }
}

function essb_map_addons_to_tmga() {
    $plugins = ESSB_Addons_Helper::get_tmga_addons();

    /*
     * Array of configuration settings. Amend each line as needed.
     *
     * TGMPA will start providing localized text strings soon. If you already have translations of our standard
     * strings available, please help us make TGMPA even better by giving us access to these translations or by
     * sending in a pull-request with .po file(s) with the translations.
     *
     * Only uncomment the strings in the config array if you want to customize the strings.
     */
    $config = array(
        'id'           => 'essb',                 // Unique ID for hashing notices for multiple instances of TGMPA.
        'default_path' => '',                      // Default absolute path to bundled plugins.
        'menu'         => 'essb_redirect_addons', // Menu slug.
        'parent_slug'  => 'essb_options',            // Parent menu slug.
        'capability'   => 'manage_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
        'has_notices'  => false,                    // Show admin notices or not.
        'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
        'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => false,                   // Automatically activate plugins after installation or not.
        'message'      => '',                      // Message to output right before the plugins table.
        'strings' => array(
            'page_title' => 'Add-Ons',
            'menu_title' => 'Add-Ons'
        )
        
    );    
    
    essb_tgmpa( $plugins, $config );
}

/**
 * Generate an array of all site plugins
 * @return unknown[][]|NULL[][]
 */
function essb_get_site_plugins() {
    $plugins = get_plugins();
    
    $r = array();
    
    foreach ($plugins as $key => $data) {
        $key_path = explode('/', $key);
        $slug = $key_path[0];
        
        $r[$slug] = array(
            'name' => $data['Name'],
            'version' => $data['Version'],
            'description' => $data['Description'],
            'pluginURL' => $data['PluginURI'],
            'author' => $data['AuthorName'],
            'path' => $key,
            'active' => is_plugin_active( $key )
        );
    }
    
    return $r;
}