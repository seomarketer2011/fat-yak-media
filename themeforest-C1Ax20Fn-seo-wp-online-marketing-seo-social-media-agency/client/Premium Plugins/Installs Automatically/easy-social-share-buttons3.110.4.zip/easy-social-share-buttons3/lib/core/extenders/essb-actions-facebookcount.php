<?php
function essb_actions_update_facebook_count()
{
	$post_id = $_POST['post_id'];
	$count = $_POST['count'];

	$post_id = sanitize_text_field($post_id);
	$count = sanitize_text_field($count);

	if (!class_exists('ESSB_Cached_Share_Counters')) {
		include_once(ESSB3_PLUGIN_ROOT . 'lib/classes/share-button/class-cached-share-counters.php');
	}

	$past_shares = ESSB_Cached_Share_Counters::get_single_network_post_counter($post_id, 'facebook');

	if ($count > $past_shares || essb_option_bool_value('cache_counter_force')) {
		ESSB_Cached_Share_Counters::save_single_network_post_counter($post_id, 'facebook', $count);
	}

	echo json_encode(array('network' => 'facebook', 'past_shares' => $past_shares, 'new_shares' => $count));

	wp_die();
}
